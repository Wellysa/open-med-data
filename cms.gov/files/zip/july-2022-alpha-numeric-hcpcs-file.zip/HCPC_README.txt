CENTERS FOR MEDICARE & MEDICAID SERVICES (CMS)
ALPHA-NUMERIC HEALTH CARE PROCEDURE CODING SYSTEM (HCPCS)
	


Alpha-Numeric HCPCS File Content

This file contains the Level II Alpha-numeric HCPCS procedure and modifier codes, their long and short descriptions, and applicable Medicare administrative, 
coverage, and pricing data.  The Level II HCPCS codes, which are established by CMS's Alpha-Numeric Editorial Panel, primarily represent items and supplies and 
non-physician services not covered by the American Medical Association's Current Procedural Terminology-4 (CPT-4) codes; Medicare, Medicaid, and private health 
insurers use HCPCS procedure and modifier codes for claims processing.  Level II alphanumeric procedure and modifier codes comprise the A to V range. 



HCPCS Update Schedule

Level II alpha-numeric procedure and modifier codes are now updated on a quarterly basis and will be posted to the CMS web site approximately 1 month before the start of a quarter.  


Ordering CPT-4 Codes

In light of copyright agreements, this file does not contain the American Medical Association's Level I CPT-4 codes nor the American Dental Association's CDT codes. 
Copies of CPT-4 code books can be purchased from the American Medical Association at 1-800-621-8335 or 515 North State Street, Chicago, Illinois 60610.  To request a copy of
the CDT codes, please contact the American Dental Association at 1-800-947-4746.    


Other HCPCS Notes
  
-- Inclusion or exclusion of a procedure, supply, product, or service does not imply any health insurance coverage or reimbursement policy.  

-- In some instances, brand names may appear in HCPCS descriptions.  These names have been included for indexing purposes only; their inclusion does not convey endorsement
   of any particular brand.  




